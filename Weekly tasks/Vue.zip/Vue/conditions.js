


    var newapp = new Vue({
        el: "#new",
        data: {
        seen: false,
        show: false,
        },
        });