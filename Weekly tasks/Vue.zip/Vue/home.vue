 <script src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js"></script>

<template>
<div>
   <h1>template in vue js</h1> 
</div>
</template>

<script>
export default{
    name: Home,
    data(){
        return{
            name:"Nisha"
        }
    }
    
};

</script>