
  // create a new Vue instance and mount it to our div element above with the id of app
  var app = new Vue({
    el: "#app",
data: {
name: "Nisha",
address: "ABC",
htmlrendering: "<h3> For this task i need to render HTML content through Vue </h3>",
htmlparagraph: "<p> This is a HTML paragraph rendered through Vue </p>",
htmlimage: "",
}
});


  