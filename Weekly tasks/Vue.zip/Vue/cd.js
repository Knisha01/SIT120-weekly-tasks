Vue.directive('purple',function(el){
    el.style.color ="Green"
  })
  
  new Vue({
    el: "#app",
    data: {}
    
  })